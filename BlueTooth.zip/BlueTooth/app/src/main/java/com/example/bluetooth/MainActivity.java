package com.example.bluetooth;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "bluetooth111";
    private static final int MY_REQUEST_PERMISSION_BLUETOOTH_CONNECT = 1;
    private static final int MY_REQUEST_PERMISSION_BLUETOOTH = 2;
    private static final int MY_REQUEST_CODE_DISCOVARABLE = 3;
    private static final int MY_REQUEST_PERMISSION_BLUETOOTH_SCAN = 4;
    private static final int MY_REQUEST_PERMISSION_BLUETOOTH_ADMIN = 5;
    private static final int MY_REQUEST_PERMISSION_BLUETOOTH_ADVERTISE = 6;
    private static final int MY_REQUEST_PERMISSION_ACCESS_FINE = 7;
    private static final int MY_REQUEST_PERMISSION_BLUETOOTH_COARSE = 8;
    private static final int MY_REQUEST_PERMISSION_BLUETOOTH_BACKGROUND_LOCATION = 9;
    BluetoothAdapter bluetoothAdapter;
    private ListView listViewPairedDevices;
    private ListView listViewNewDevices;
    private ArrayAdapter<String> stringArrayAdapterPD;
    private ArrayAdapter<String>stringArrayAdapterND;
    ArrayList<String>listPD;
    ArrayList<String>listND;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
}